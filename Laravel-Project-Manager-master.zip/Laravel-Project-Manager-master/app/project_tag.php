<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class project_tag extends Model
{
    //
}
