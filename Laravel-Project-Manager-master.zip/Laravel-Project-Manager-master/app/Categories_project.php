<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categories_project extends Model
{
    //
}
