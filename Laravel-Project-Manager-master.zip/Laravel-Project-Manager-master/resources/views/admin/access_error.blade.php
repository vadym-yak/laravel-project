@extends('admin.default')

@section('error')
    <div class="col s12">
        <div class="card">
            <div class="card-title red white-text center">
                You don't have permission to access this page !
            </div>
        </div>
    </div>
@stop